/**
 * 
 */
/**
 * 
 */
module ProjektJava {
	requires java.sql;
}