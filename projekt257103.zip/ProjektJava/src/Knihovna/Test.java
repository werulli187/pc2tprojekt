package Knihovna;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;


public class Test {

	public static int pouzeCelaCisla(Scanner sc) 
	{
		int cislo = 0;
		try
		{
			cislo = sc.nextInt();
		}
		catch(Exception e)
		{
			System.out.println("Nastala vyjimka typu "+e.toString());
			System.out.println("zadejte prosim cele cislo ");
			sc.nextLine();
			cislo = pouzeCelaCisla(sc);
		}
		return cislo;
	}
	
	public static float pouzeCisla(Scanner sc) 
	{
		float cislo = 0;
		try
		{
			cislo = sc.nextFloat();
		}
		catch(Exception e)
		{
			System.out.println("Nastala vyjimka typu "+e.toString());
			System.out.println("zadejte prosim cislo ");
			sc.nextLine();
			cislo = pouzeCisla(sc);
		}
		return cislo;
	}

	public static void main(String[] args) {	
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Databazeknih mojeDatabazeknih=new Databazeknih();
		int volba = 0;
		String nazev;
		String autor;
		int rok;
		boolean dostupnost;
		String zanr;
		int vhodnost;
		boolean run=true;
		while(run)
		{
			System.out.println("Nacházíte se v aplikaci knihovny");
			System.out.println("Vyberte požadovanou činnost:");
			System.out.println("1 .. vložení nové knihy"); 
			System.out.println("2 .. upravení knihy"); 
			System.out.println("3 .. smazání knihy"); 
			System.out.println("4 .. označení stavu knihy jako vrácená"); 
			System.out.println("5 .. výpis knih v databázi v abecedním pořadí"); 
			System.out.println("6 .. vyhledání knihy");
			System.out.println("7 .. výpis všech knih daného autora v chronologickém pořadí");
			System.out.println("8 .. výpis všech knih, které patří do konkrétního žánru");
			System.out.println("9 .. výpis všech vypůjčených knih s informací jestli se jedná o učebnici či román");
			System.out.println("10 .. uložení knihy dle názvu do souboru");
			System.out.println("11 .. načtení všech informací o dané knize ze souboru");
			
			
			volba=pouzeCelaCisla(sc);
			switch(volba)
			{
			case 1:
			    System.out.println("Zadej typ knihy: (román-R/ucebnice-U)");
			    String typKnihy = sc.next();

			    if (typKnihy.equalsIgnoreCase("R")) {
			    	System.out.println("Zadejte název knihy, autora, rok vydání, dostupnost:");
				    nazev = sc.next();
				    autor = sc.next();
				    rok = Test.pouzeCelaCisla(sc);
				    dostupnost = sc.nextBoolean();
			       
			    	System.out.println("Zadej žánr: ");
			    	zanr = sc.next(); 
			    	
			    	if (!mojeDatabazeknih.setKnihy(nazev, autor, rok, dostupnost, zanr)) {
			    	    System.out.println("Román již existuje v databázi.");
			    	} else {
			    	    System.out.println("Román úspěšně přidán do databáze.");
			    	}
			    } 
			    else if (typKnihy.equalsIgnoreCase("U")) {
			    	System.out.println("Zadejte název knihy, autora, rok vydání, dostupnost:");
				    nazev = sc.next();
				    autor = sc.next();
				    rok = Test.pouzeCelaCisla(sc);
				    dostupnost = sc.nextBoolean();
			        
			        System.out.println("Zadejte vhodnost pro učebnici(jaký ročník):");
			        vhodnost = Test.pouzeCelaCisla(sc);
			        if (!mojeDatabazeknih.setKnihy(nazev, autor, rok, dostupnost, vhodnost)) {
			    	    System.out.println("Učebnice již existuje v databázi.");
			    	} else {
			    	    System.out.println("Učebnice úspěšně přídána do databáze");
			    	}
			    } 
			     else {
			        System.out.println("Neplatný typ knihy.");
			    }
			    break;

			case 2: 
			    System.out.println("Zadejte název knihy, kterou chcete upravit:");
			    nazev = sc.next(); 
			    Knihy kniha = mojeDatabazeknih.getKnihy(nazev); 

			    if (kniha != null) { 
			        System.out.println("Vyberte možnost úpravy:");
			        System.out.println("1. Úprava autora/autorů");
			        System.out.println("2. Úprava roku vydání");
			        System.out.println("3. Úprava stavu dostupnosti");

			        int volbaUpravy = pouzeCelaCisla(sc); 

			        switch (volbaUpravy) {
			            case 1:
			                System.out.println("Zadejte nového autora/autory:");
			                String novyAutor = sc.next(); 
			                kniha.setAutor(novyAutor); 
			                break;
			            case 2:
			                System.out.println("Zadejte nový rok vydání:");
			                int novyRokVydani = pouzeCelaCisla(sc); 
			                kniha.setRokVydani(novyRokVydani); 
			                break;
			            case 3:
			                System.out.println("Zadejte nový stav dostupnosti (true/k dispozici, false/vypůjčeno):");
			                boolean novyStavDostupnosti = Boolean.parseBoolean(sc.nextLine()); 
			                kniha.setDostupnost(novyStavDostupnosti); 
			                break;
			            default:
			                System.out.println("Neplatná volba.");
			        }
			    } else {
			        System.out.println("Kniha s tímto názvem neexistuje v databázi.");
			    }
			    break;

			case 3:
				System.out.println("Zadejte jmeno knihy k odstraneni");
				nazev=sc.next();
				if (mojeDatabazeknih.odstranitKnihu(nazev))
					System.out.println(nazev + " úspěšně odstraněn ");
				else
					System.out.println(nazev + " není v databázi ");
				break;
				
			case 4:
			    System.out.println("Zadej název knihy, která byla vrácena:");
			    nazev = sc.next();
			    
			    kniha = mojeDatabazeknih.getKnihy(nazev);
			    
			    if (kniha != null) {
			        
			        kniha.setDostupnost(true); 
			        System.out.println("Kniha " + nazev + " byla označena jako vrácená.");
			    } else {
			        
			        System.out.println("Kniha s názvem " + nazev + " nebyla nalezena.");
			    }
			    break;
			    
			case 5:
				mojeDatabazeknih.vypisDatabaze();
				break;
				
			case 6: 
				System.out.println("Zadejte název knihy, o které chcete zobrazit informace: ");
				nazev = sc.next();
				kniha = mojeDatabazeknih.getKnihy(nazev);
				
				if(kniha != null) {
					mojeDatabazeknih.vyhledatKnihu(nazev);
				}
				else {
			       
			        System.out.println("Kniha s názvem " + nazev + " nebyla nalezena.");
			    }
				break;
				
			case 7: 
				System.out.println("Zadejte autora knih: ");
				autor = sc.next();
					
				if(autor!=null);
				 	mojeDatabazeknih.knihyAutora(autor);
				
				break;
			case 8: 
				System.out.println("Zadejte požadovaný žánr: ");
				zanr = sc.next();
				
				if(zanr!=null);
					mojeDatabazeknih.vypisZanru(zanr);	
				break;
			
			case 9:
				System.out.println("Seznam vypůjčených knih: ");
				mojeDatabazeknih.vypujceneKnihy(false);
			
				break;
			case 10:
				 try {
			            BufferedWriter writer = new BufferedWriter(new FileWriter("output.txt"));
			            System.out.println("Zadejte název knihy, kterou chcete zapsat do souboru: ");
			            nazev = sc.next();
			            kniha = mojeDatabazeknih.getKnihy(nazev);
			            
			            if (kniha != null) {
			                writer.write("Název: " + kniha.getNazev() + "\n");
			                writer.write("Autor: " + kniha.getAutor() + "\n");
			                writer.write("Rok vydání: " + kniha.getRok() + "\n");
			                writer.write("Dostupnost: " + (kniha.getDostupnost() ? "true" : "false") + "\n");
			                if (kniha.getZanr() != null) {
			                    writer.write("Žánr: " + kniha.getZanr() + "\n");
			                } else {
			                    writer.write("Vhodnost: " + kniha.getVhodnost() + "\n");
			                }
			                System.out.println("Informace o knize úspěšně zapsány do souboru.");
			            } else {
			                System.out.println("Knihu s tímto názvem nelze nalézt.");
			            }

			            writer.close();
			        } catch (IOException e) {
			            e.printStackTrace();
			        }
			        break;
			case 11: 
			    try (BufferedReader reader = new BufferedReader(new FileReader("output.txt"))) {
			        
			        nazev = reader.readLine(); 
			        autor = reader.readLine(); 
			        String rokString = reader.readLine().substring("Rok vydání: ".length());
			        rok = Integer.parseInt(rokString);
			        zanr = null;
			        vhodnost = 0;
			       
			        String dostupnostString = reader.readLine().substring("Dostupnost: ".length());
			        dostupnost = Boolean.parseBoolean(dostupnostString);
			       
			        String nextLine;
			        while ((nextLine = reader.readLine()) != null) {
			            if (nextLine.startsWith("Žánr: ")) {
			                zanr = nextLine.substring("Žánr: ".length());
			            } else if (nextLine.startsWith("Vhodnost: ")) {
			                vhodnost = Integer.parseInt(nextLine.substring("Vhodnost: ".length()));
			            }
			        }
			        
			        kniha = new Knihy(nazev, autor, rok, dostupnost, zanr, vhodnost);

			        System.out.println(kniha.getNazev());
			        System.out.println(kniha.getAutor());
			        System.out.println("Rok vydání: " + kniha.getRok());
			        System.out.println("Dostupnost: " + (kniha.getDostupnost() ? "Dostupná" : "Nedostupná"));
			        if (kniha.getZanr() != null) {
			            System.out.println("Žánr: " + kniha.getZanr());
			        } else {
			            System.out.println("Vhodnost: " + kniha.getVhodnost());
			        }
			    }

			     catch (IOException e) {
			        e.printStackTrace();
			    } catch (NumberFormatException e) {
			        System.err.println("Chyba při zpracování číselné hodnoty ze souboru.");
			        e.printStackTrace();
			    }
			    break;



			    default:
			    	System.out.println("Neplatná volba. Zkuste to znovu.");
		}
		} while (volba != 0);

        sc.close();
	}
}