package Knihovna;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;
import java.util.HashSet;

public class DBConnection {
    private Connection connection; 

    public boolean getDBConnection() { 
        if (connection == null) {
            try {
                Class.forName("org.sqlite.JDBC");
                connection = DriverManager.getConnection("jdbc:sqlite:knihovna.db"); 
                createTables();
            } catch (SQLException | ClassNotFoundException e) {
                e.printStackTrace();
                return false;
            }
        }
        return true;
    }

    public void closeConnection() { 
        try {
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void createTables() { 
        String sqlKnihy = "CREATE TABLE IF NOT EXISTS knihy (" +
                "nazev TEXT," +
                "autor TEXT," +
                "rok INTEGER," +
                "dostupnost INTEGER," +
                "zanr TEXT," +
                "vhodnost INTEGER" +
                ");";

        try {
            Statement stmt = connection.createStatement();
            stmt.execute(sqlKnihy);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void saveToDB(Knihy kniha) { 
        String sql = "INSERT INTO knihy (nazev, autor, rok, dostupnost, zanr, vhodnost) VALUES (?,?,?,?,?,?)";
        try {
            PreparedStatement pstmt = connection.prepareStatement(sql);
            pstmt.setString(1, kniha.getNazev());
            pstmt.setString(2, kniha.getAutor());
            pstmt.setInt(3, kniha.getRok());
            pstmt.setInt(4, kniha.getDostupnost() ? 1 : 0);
            pstmt.setString(5, kniha.getZanr());
            pstmt.setInt(6, kniha.getVhodnost());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public HashSet<Knihy> loadFromDB() { 
        HashSet<Knihy> knihy = new HashSet<>();
        String sql = "SELECT * FROM knihy";
        try {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                String nazev = rs.getString("nazev");
                String autor = rs.getString("autor");
                int rok = rs.getInt("rok");
                boolean dostupnost = rs.getInt("dostupnost") == 1;
                String zanr = rs.getString("zanr");
                int vhodnost = rs.getInt("vhodnost");
                Knihy kniha = new Knihy(nazev, autor, rok, dostupnost, zanr, vhodnost);
                knihy.add(kniha);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return knihy;
    }
}

