package Knihovna;
import java.util.HashMap;
import java.util.Map;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class Databazeknih {
    private Map<String, Knihy> knihyDatabaze;

    public Databazeknih() {
        knihyDatabaze = new HashMap<String,Knihy>();
    }

    public boolean setKnihy(String nazev,String autor,int rok,boolean dostupnost,String zanr)
	{
		if (knihyDatabaze.put(nazev,new Knihy(nazev,autor,rok,dostupnost, zanr, 0))==null)
			return true;
		else
			return false;
	}
    public boolean setKnihy(String nazev,String autor,int rok,boolean dostupnost,int vhodnost)
 	{
 		if (knihyDatabaze.put(nazev,new Knihy(nazev,autor,rok,dostupnost, null, vhodnost))==null)
 			return true;
 		else
 			return false;
 	}

    public Knihy getKnihy(String nazev) {
        return knihyDatabaze.get(nazev);
    }

    public boolean odstranitKnihu(String nazev) {
        if (knihyDatabaze.remove(nazev)!=null)
            return true;
        return false;
    }
    
    public void vypisDatabaze() { 
        
        List<String> seznamKnih = new ArrayList<>(knihyDatabaze.keySet());
        Collections.sort(seznamKnih);

        
        for (String nazev : seznamKnih) {
            Knihy kniha = knihyDatabaze.get(nazev);
            String autor = kniha.getAutor();
            int rok = kniha.getRok();
            boolean dostupnost = kniha.getDostupnost();
            System.out.println("Název: " + nazev + ", Autor: " + autor + ", Rok vydání: " + rok + ", Dostupnost: " + dostupnost);
        }
      }
    
    public void vyhledatKnihu(String nazev) { 
       
        if (knihyDatabaze.containsKey(nazev)) {
            Knihy kniha = knihyDatabaze.get(nazev);
            String autor = kniha.getAutor();
            int rok = kniha.getRok();
            boolean dostupnost = kniha.getDostupnost();
            String zanr = kniha.getZanr();
            int vhodnost = kniha.getVhodnost();
            if(zanr!=null) {
            	System.out.println("Název: " + nazev + ", Autor: " + autor + ", Rok vydání: " + rok + ", Dostupnost: " + dostupnost + ", Žánr: " + zanr);
            }
            else {
            	System.out.println("Název: " + nazev + ", Autor: " + autor + ", Rok vydání: " + rok + ", Dostupnost: " + dostupnost + ", Vhodné pro ročník: " + vhodnost);
            }     	
        }
    }
    public void knihyAutora(String autor) { 
        
        List<String> seznamKnihAutora = new ArrayList<>();

        
        for (Map.Entry<String, Knihy> entry : knihyDatabaze.entrySet()) {
            Knihy kniha = entry.getValue();
            if (kniha.getAutor().equalsIgnoreCase(autor)) {
                seznamKnihAutora.add(entry.getKey()); 
            }
        }

        
        if (seznamKnihAutora.isEmpty()) {
            System.out.println("Žádná kniha od autora " + autor + " nenalezena.");
            return;
        }

        Collections.sort(seznamKnihAutora, new Comparator<String>() {
            @Override
            public int compare(String kniha1, String kniha2) {
                int rok1 = knihyDatabaze.get(kniha1).getRok();
                int rok2 = knihyDatabaze.get(kniha2).getRok();
                return Integer.compare(rok1, rok2);
            }
        });
        
        System.out.println("Knihy od autora " + autor + " seřazené dle roku vydání:");
        for (String nazev : seznamKnihAutora) {
            Knihy kniha = knihyDatabaze.get(nazev);
            int rok = kniha.getRok();
            boolean dostupnost = kniha.getDostupnost();
            String zanr = kniha.getZanr();
            System.out.println("Název: " + nazev + ", Autor: " + autor + ", Rok vydání: " + rok + ", Dostupnost: " + dostupnost + ", Žánr: "+ zanr);
        }
       }
    public void vypisZanru(String zanr) { 
    	 List<String> seznamZanru = new ArrayList<>();

         for (Map.Entry<String, Knihy> entry : knihyDatabaze.entrySet()) {
             Knihy kniha = entry.getValue();
             if (kniha.getZanr().equalsIgnoreCase(zanr)) {
                 seznamZanru.add(entry.getKey()); 
             }
         }

         if (seznamZanru.isEmpty()) {
             System.out.println("Žádná kniha ze žánru " + zanr + " nenalezena.");
             return;
         }
         
         System.out.println("Knihy typ žánru: " + zanr);
         for (String nazev : seznamZanru) {
             Knihy kniha = knihyDatabaze.get(nazev);
             String autor = kniha.getAutor();
             int rok = kniha.getRok();
             boolean dostupnost = kniha.getDostupnost();
             System.out.println("Název: " + nazev + ", Autor: " + autor + ", Rok vydání: " + rok + ", Dostupnost: " + dostupnost + "Žánr: " + zanr);
         }
    }
    public void vypujceneKnihy(boolean dostupnost) { 
        boolean vypujceny = false;
        for (Map.Entry<String, Knihy> entry : knihyDatabaze.entrySet()) {
            Knihy kniha = entry.getValue();
            if (kniha.getDostupnost() == dostupnost) {
                String nazev = entry.getKey();
                String autor = kniha.getAutor();
                String typKnihy = kniha.getTypKnihy();
                System.out.println("Název: " + nazev + ", Autor: " + autor + ", Kategorie: " + typKnihy);
                vypujceny = true;
            }
        }
        if (!vypujceny) {
            System.out.println("Žádná vypůjčená kniha nenalezena.");
        }
    }
 
       
    }