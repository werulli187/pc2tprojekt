package Knihovna;
public class Knihy {
	
	private String nazev;
	private String autor;
	private int rok;
	private boolean dostupnost;
	private String zanr;
	private int vhodnost;
	private String typKnihy;
	
	public Knihy(String nazev, String autor, int rok, boolean dostupnost, String zanr, int vhodnost) {
		this.nazev=nazev;
		this.autor=autor;
		this.rok=rok;
		this.dostupnost=dostupnost;
		this.zanr=zanr;
		this.vhodnost=vhodnost;
	}
	public String getNazev()
	{
		return nazev;
	}
	public String getAutor()
	{
		return autor;
	}
	public int getRok()
	{
		return rok;
	}
	public boolean getDostupnost()
	{
		return dostupnost;
	}
	public String getZanr()
	{
		return zanr;
	}
	public int getVhodnost()
	{
		return vhodnost;
	}
	public String getTypKnihy() {
	    if (zanr != null)
	        return "Román";
	    else if (vhodnost != 0)
	    	return "Učebnice";
	    else
	        return "Neznámý typ"; 
	}

	public void setAutor(String novyAutor) {
		this.autor = novyAutor;
		
	}
	public void setRokVydani(int novyRokVydani) {
		this.rok = novyRokVydani;
		
	}
	public void setDostupnost(boolean novyStavDostupnosti) {
		this.dostupnost = novyStavDostupnosti;
		
	}
}
